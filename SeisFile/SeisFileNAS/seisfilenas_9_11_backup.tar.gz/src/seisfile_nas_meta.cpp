/*
 * seisfile_nas_meta.cpp
 *
 *  Created on: July 31, 2018
 *      Author: cssl
 */

 #include "seisfile_nas_meta.h"
 #include <iostream>
 #include <string.h>
 #include <stdio.h>

 namespace seisfs {
	namespace file{

		MetaNAS::MetaNAS(const std::string &data_name, const HeadType &head_type, const TraceType& trace_type, Lifetime lifetime_days){
			_metauser = 1;
			_filename = data_name;
			_head_type = head_type;
			_trace_type = trace_type;
			_lifetime_days = lifetime_days;
			_keynum = head_type.head_size.size();
			_gf_meta = new GEFile(_filename);
			_gf_meta->SetProjectName(_filename);
			_gf_meta->Open(IO_READWRITE, false);
			_head_length = 0;
			for(int i = 0; i < _head_type.head_size.size(); i++){
				_head_length += _head_type.head_size[i];
			}
			if(_gf_meta->GetLength() == 0){//file does not exit before
				_lifetimestat = NORMAL;
				time(&_creat_time);
				_lastmodify_time = 0;
				printf("create time is:%lu\n",_creat_time);
			}
			/*else{
				time(&_lastmodify_time);  //file exits and now modify ite does not exit before
				printf("modifytime is:%lu\n",_lastmodify_time);

			}*/
			//time(&_creat_time);
			//_lastmodify_time = _creat_time;
		}

		MetaNAS::MetaNAS(const std::string &data_name, const HeadType &head_type, Lifetime lifetime_days){
			_metauser = 1;
			_filename = data_name;
			_head_type = head_type;
			_lifetime_days = lifetime_days;
			_keynum = head_type.head_size.size();
			_gf_meta = new GEFile(_filename);
			_gf_meta->SetProjectName(_filename);
			_gf_meta->Open(IO_READWRITE, false);
			_head_length = 0;
			for(int i = 0; i < _head_type.head_size.size(); i++){
				_head_length += _head_type.head_size[i];
			}
			if(_gf_meta->GetLength() == 0){//file does not exit before
				_lifetimestat = NORMAL;
				time(&_creat_time);
				_lastmodify_time = 0;
			}
		}

		MetaNAS::MetaNAS(const std::string &data_name, const TraceType& trace_type, Lifetime lifetime_days){
			_metauser = 1;
			_filename = data_name;
			_trace_type = trace_type;
			_lifetime_days = lifetime_days;
			_keynum = 0;
			_gf_meta = new GEFile(_filename);
			_gf_meta->SetProjectName(_filename);
			_gf_meta->Open(IO_READWRITE, false);
			if(_gf_meta->GetLength() == 0){//file does not exit before
				_lifetimestat = NORMAL;
				time(&_creat_time);
				_lastmodify_time = 0;
			}
		}

		MetaNAS::MetaNAS(const std::string &data_name){
			//printf("---------reader or updater is using meta----------\n");
			_metauser = 0;
			_filename = data_name;
			_gf_meta = new GEFile(_filename);
			_gf_meta->SetProjectName(_filename);
			_gf_meta->Open(IO_READWRITE,false);
			_gf_meta->SeekToBegin();
		}

		MetaNAS::~MetaNAS(){
			_gf_meta->Close();
			delete _gf_meta;
		}


		bool MetaNAS::MetaRead(){
			char p[sizeof(unsigned int)],p1[sizeof(int)],p2[sizeof(time_t)],p3[sizeof(uint16_t)];
			if(_gf_meta->GetLength() == 0){ //empty metafile
				//MetaNAS::Init();
				_head_num = 0;
				_trace_num = 0;
			}
			else{ //data exits,needs to read, modify and update
				/*										//these won't be changed after first write
				 *	lastmodifytime	/lifetimestat/	Lifetime	headnum		tracenum	creattime	keynum		headtype			headlength	tracetype
				 *	time_t			/int/				int			uint32_t	uint32_t	time_t		int			vector<uint16_t>	uint32_t	uint32_t
				 */
				int timestat;

				_gf_meta->Read(p2, sizeof(time_t));
				memcpy(&_lastmodify_time, p2, sizeof(time_t));
				_gf_meta->Read(p1, sizeof(int));

				/////////////////////////////////////////
				memcpy(&_lifetimestat, p1, sizeof(int));
				_gf_meta->Read(p1, sizeof(Lifetime));
				/////////////////////////////////////////

				memcpy(&_lifetime_days, p1, sizeof(Lifetime));
				_gf_meta->Read(p, sizeof(uint32_t));
				memcpy(&_head_num, p, sizeof(uint32_t));
				_gf_meta->Read(p, sizeof(uint32_t));
				memcpy(&_trace_num, p, sizeof(uint32_t));
				_gf_meta->Read(p2, sizeof(time_t));
				memcpy(&_creat_time, p2, sizeof(time_t));
			}
			if(_metauser == 0){
				_gf_meta->Read(p1, sizeof(int));
				memcpy(&_keynum, p1, sizeof(int));
				uint16_t temp = 0;
				//uint32_t templength = 0;
				for(int i = 0; i < _keynum; i++){
					_gf_meta->Read(p3, sizeof(uint16_t));
					memcpy(&temp, p3, sizeof(uint16_t));
					//templength += temp;
					_head_type.head_size.push_back(temp);
				}
				_gf_meta->Read(p, sizeof(uint32_t));
				memcpy(&_head_length, p, sizeof(uint32_t));
				_gf_meta->Read(p, sizeof(uint32_t));
				//memcpy(&temp, p, sizeof(uint32_t));
				//_trace_type.trace_size = temp;
				memcpy(&_trace_type.trace_size, p, sizeof(uint32_t));
			}

			//printf("last:%lu,life:%d,headn:%u,tracen:%u,cret:%lu,keynum:%d,headl:%u,tracel:%u\n",
				//				_lastmodify_time,_lifetime_days,_head_num,_trace_num,_creat_time,_keynum,_head_length,_trace_type.trace_size);
			return true;
		}

		bool MetaNAS::MetaUpdate(){
			//std::cout<<"update comein\n";
			int judge = 0; //to judge if it is the first time to write
			if(_gf_meta->GetLength() == 0){
				judge = 1;
			}
			char p[sizeof(unsigned int)],p1[sizeof(int)],p2[sizeof(uint16_t)],p3[sizeof(time_t)];

			//std::cout<<"1\n";
			_gf_meta->SeekToBegin();
			time(&_lastmodify_time);
			//printf("this time update is:%lu\n",_lastmodify_time);
			memcpy(p3, &_lastmodify_time, sizeof(time_t));
			_gf_meta->Write(p3, sizeof(time_t));

			////////////////////////////////////////////
			memcpy(p1, &_lifetimestat, sizeof(int));
			_gf_meta->Write(p1,sizeof(int));
			////////////////////////////////////////////

			memcpy(p1, &_lifetime_days, sizeof(Lifetime));
			_gf_meta->Write(p1, sizeof(int));
			memcpy(p, &_head_num, sizeof(uint32_t));
			_gf_meta->Write(p, sizeof(uint32_t));
			memcpy(p, &_trace_num, sizeof(uint32_t));
			_gf_meta->Write(p, sizeof(uint32_t));

			//std::cout<<"2\n";

			if(judge == 1){	//following message won't change
				//printf("writemetanochangethings\n");
				memcpy(p3, &_creat_time, sizeof(time_t));
				_gf_meta->Write(p3, sizeof(time_t));
				memcpy(p1, &_keynum, sizeof(int));
				_gf_meta->Write(p1, sizeof(int));
				for(int i = 0; i < _keynum; i++){
					//printf("%d ",_head_type.head_size[i]);
					uint16_t tmp = _head_type.head_size[i];
					memcpy(p2, &tmp, sizeof(uint16_t));
					_gf_meta->Write(p2, sizeof(uint16_t));
				}
				//std::cout<<"\n";
				memcpy(p, &_head_length, sizeof(uint32_t));
				_gf_meta->Write(p, sizeof(uint32_t));
				memcpy(p2, &_trace_type.trace_size, sizeof(uint16_t));
				_gf_meta->Write(p2, sizeof(uint16_t));
			}

			//std::cout<<"3\n";
			/*printf("last:%lu,life:%d,headn:%u,tracen:%u,cret:%lu,keynum:%d,headl:%u,tracel:%u\n",
					_lastmodify_time,_lifetime_days,_head_num,_trace_num,_creat_time,_keynum,_head_length,_trace_type.trace_size);*/

			_gf_meta->Flush();
			return true;
		}

		void MetaNAS::MetaheadnumPlus(){
			_head_num++;
		}

		void MetaNAS::MetatracenumPlus(){
			_trace_num++;
		}

		HeadType MetaNAS::MetaGetheadtype(){
			return _head_type;
		}

		TraceType MetaNAS::MetaGettracetype(){
			return _trace_type;
		}

		void MetaNAS::MetaSetheadnum(const uint32_t& headnum){
			_head_num = headnum;
			MetaNAS::MetaUpdate();
		}

		void MetaNAS::MetaSettracenum(const uint32_t& tracenum){
			_trace_num = tracenum;
			MetaNAS::MetaUpdate();
		}

		uint32_t MetaNAS::MetaGetheadnum(){
			return _head_num;
		}

		uint32_t MetaNAS::MetaGettracenum(){
			return _trace_num;
		}

		uint32_t MetaNAS::MetaGetheadlength(){
			return _head_length;
		}

		uint32_t MetaNAS::MetaGettracelength(){
			return _trace_type.trace_size;
		}

		uint32_t MetaNAS::MetaGetkeynum(){
			return _keynum;
		}

		time_t MetaNAS::MetaGetLastModify(){
			return _lastmodify_time;
		}

		bool MetaNAS::MetaSetLifetime(Lifetime lifetime_days){
			_lifetime_days = lifetime_days;
			MetaNAS::MetaUpdate();
			return true;
		}

		Lifetime MetaNAS::MetaGetLifetime(){
			return _lifetime_days;
		}

		LifetimeStat MetaNAS::MetaGetLifetimestat(){
			return _lifetimestat;
		}

		LifetimeStat MetaNAS::MetaSetLifetimestat(LifetimeStat lt_stat){
			_lifetimestat = lt_stat;
			MetaNAS::MetaUpdate();
			return _lifetimestat;
		}

	}
 }
