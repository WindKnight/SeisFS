/*
 * seisfile_nas_reader.cpp
 *
 *  Created on: Aug 5, 2018
 *      Author: cssl
 */

#include "seisfile_nas_reader.h"
#include <seisfile_nas_meta.h>
#include <stdio.h>

//for test
#include <malloc.h>
#include <string.h>

namespace seisfs {
namespace file {

ReaderNAS::ReaderNAS(const std::string& filename) {
	_head_filename = SEISNAS_HOME_PATH + filename + "_head";
	_trace_filename = SEISNAS_HOME_PATH + filename + "_trace";
	_meta_filename = SEISNAS_HOME_PATH + filename +"_meta";
	_filename = filename;
	ReaderNAS::Init();
}

bool ReaderNAS::Init() {
	_gf_head = new GEFile(_head_filename);
	_gf_trace = new GEFile(_trace_filename);
	_gf_head->SetProjectName(_filename + "head");
	_gf_trace->SetProjectName(_filename + "trace");
	_meta = new MetaNAS(_meta_filename);
	_meta->MetaRead();
	return (_gf_head->Open(IO_READONLY, true) && _gf_trace->Open(IO_READONLY, true));
}

ReaderNAS::~ReaderNAS() {
//	MetaNAS::~MetaNAS();
}

/*
 * caller should not delete the pointer of filter after calling this function
 */
bool ReaderNAS::SetHeadFilter(const HeadFilter& head_filter) {
	_head_filter = head_filter;
	return true;
}

/*
 * caller should not delete the pointer of filter after calling this function
 */
bool ReaderNAS::SetRowFilter(const RowFilter& row_filter) {
	_row_filter = row_filter;
	return true;
}


int ReaderNAS::GetTraceSize() {
	_trace_type = _meta->MetaGettracetype();
	return _trace_type.trace_size;
}

int ReaderNAS::GetHeadSize() {
	_head_type = _meta->MetaGetheadtype();
	uint32_t headlength = 0;
	/*for(int i = 0; i < _head_filter.NumKeys(); i++){
		headlength += _head_type.head_size[_head_filter.NumKeys()[i]];
	}*/
	for(auto i = _head_filter.GetKeyList().begin(); i != _head_filter.GetKeyList().end(); i++){
		headlength += _head_type.head_size[(*i)];
	}
	return headlength;

} //return length of one head, in bytes

uint64_t ReaderNAS::GetTraceNum() {
	int64_t tracenum = 0;
	int64_t temp = 0;
	for(int i = 0; i < _row_filter.GetAllScope().size(); i++){
		if(_row_filter.GetAllScope()[i].GetStopTrace() != -1){
			temp = _row_filter.GetAllScope()[i].GetStopTrace() - _row_filter.GetAllScope()[i].GetStartTrace() + 1;
		}
		else{
			temp = (_meta->MetaGetheadnum()>_meta->MetaGettracenum()?_meta->MetaGetheadnum():_meta->MetaGettracenum())
					- _row_filter.GetAllScope()[i].GetStartTrace();
		}
		tracenum += temp;
	}
	return tracenum;
}

/**
 * Move the read offset to head_idx(th) head.
 */
bool ReaderNAS::Seek(int64_t trace_num) {
	if(trace_num > ReaderNAS::GetTraceNum() - 1){//_meta->MetaGettracenum() - 1){
		//index out of range
		printf("trace index out of range!\n");
		return false;
	}
	int64_t head_pos = 0, trace_pos = 0;
	/*head_pos = trace_num * meta->MetaGetheadlength();
	trace_pos = trace_num * meta->MetaGettracelength();
	_gf_head->Seek(head_pos, SEEK_SET);
	_gf_trace->Seek(trace_pos, SEEK_SET);
	return true;*/
	int64_t count = 0;  //find actual tracenum by checking rowfilter
	int64_t cur_scope_num = 0;
	int64_t temp;  //record tracenum of one scope
	//printf("row_filter num is:%d\n",_row_filter.GetAllScope().size());
	//printf("count:%d,trace_num:%d,cur_scope_num:%d,rownum:%d\n",count,trace_num,cur_scope_num,_row_filter.GetAllScope().size());
	while((count <= trace_num) && (cur_scope_num < _row_filter.GetAllScope().size())){
		if(_row_filter.GetAllScope()[cur_scope_num].GetStopTrace() != -1){
			temp = _row_filter.GetAllScope()[cur_scope_num].GetStopTrace() - _row_filter.GetAllScope()[cur_scope_num].GetStartTrace() + 1;
		}
		else{
			//printf("starttrace is:%d\n",_row_filter.GetAllScope()[cur_scope_num].GetStartTrace());
			//temp = (_meta->MetaGetheadnum()>_meta->MetaGetheadnum()?_meta->MetaGetheadnum():_meta->MetaGetheadnum())
				//	- _row_filter.GetAllScope()[cur_scope_num].GetStartTrace();
			temp = trace_num - _row_filter.GetAllScope()[cur_scope_num].GetStartTrace() + 1;
		}
		count += temp;
		cur_scope_num++;
		//printf("temp is:%d\n",temp);
	}
	//printf("count is:%d\n",count);
	cur_scope_num--;
	temp = (_row_filter.GetAllScope()[cur_scope_num].GetStopTrace() == -1) ? trace_num : _row_filter.GetAllScope()[cur_scope_num].GetStopTrace();
	_actual_trace_num = temp - (count - trace_num) + 1;
	head_pos = _actual_trace_num * _meta->MetaGetheadlength();
	trace_pos = _actual_trace_num * _meta->MetaGettracelength();
	//printf("actual_trace_num is:%d,head_pos:%d\n\n",_actual_trace_num,head_pos);
	_gf_head->Seek(head_pos, SEEK_SET);
	_gf_trace->Seek(trace_pos, SEEK_SET);

	return true;
}

int64_t ReaderNAS::Tell() {
	int64_t pos = _gf_head->GetPosition();
	int64_t physical_tracenum = pos / _meta->MetaGetheadlength();
	//printf("physical tacenum is:%d\n",physical_tracenum);
	int64_t trace_num = 0;
	int64_t temp = 0;
	int mark = 0;
	for(int i = 0; i < _row_filter.GetAllScope().size(); i++){
		if(mark == 1){
			break;
		}
		temp = (_row_filter.GetAllScope()[i].GetStopTrace() == -1)?_meta->MetaGettracenum():_row_filter.GetAllScope()[i].GetStopTrace();
		for(int64_t j = _row_filter.GetAllScope()[i].GetStartTrace(); j <= temp; j++){
			if(physical_tracenum != j){
				trace_num++;
			}
			else{
				mark = 1;
				break;
			}
		}
	}
	trace_num++;
	return trace_num;
}

bool ReaderNAS::Get(int64_t trace_num, void *head, void* trace){ //(int64_t head_idx, void* head) {
	/*int *p_read = (int*)head;
	for(int i = 0; i < 128; ++i) {
		p_read[i] = -head_idx;
	}
	return true;*/
	/*ReaderNAS::Seek(trace_num);
	char *p = (char *)malloc(meta->MetaGetheadlength());
	_gf_head->Read(p, meta->MetaGetheadlength());
	int64_t i = 0;
	HeadType headtype = meta->MetaGetheadtype();
	while(i < headtype.head_size.size()){
		int mark = 0;
		for(int64_t j = 0; j < _head_filter.NumKeys(); j++){
			if(headtype.head_size[i] == _head_filter.GetKeyList()[j]){
				mark
			}
		}
	}*/
	//read head
	char *p = (char *)head;
	//memset(p, ReaderNAS::GetHeadSize(), 0);
	int64_t offset_in_head = 0;
	int64_t one_key_size = 0;
	/*for(int64_t i = 0; i < _head_filter.NumKeys(); i++){
		ReaderNAS::Seek(trace_num);  //seek to the start of excepted head
		offset_in_head = 0;
		HeadType headtype = _meta->MetaGetheadtype();
		int64_t j = 0;
		while(j < _head_filter.GetKeyList()[i] - 1){
			offset_in_head += headtype.head_size[j];   //find the position of the key
			j++;
		}
		j++;
		one_key_size = headtype.head_size[j];
		_gf_head->Seek(offset_in_head, SEEK_CUR);  //seek to the key position
		_gf_head->Read(p, one_key_size);
		p += one_key_size;
	}*/
	for(auto i = _head_filter.GetKeyList().begin(); i != _head_filter.GetKeyList().end(); ++i){
		//printf("i is:%d\n",(*i));
		//ReaderNAS::Seek(trace_num);  //seek to the start of excepted head
		//printf("position is%d\n",_gf_head->GetPosition());
		offset_in_head = 0;
		HeadType headtype = _meta->MetaGetheadtype();
		/*for(int t = 0;t < headtype.head_size.size(); t++){
			printf("%d ",headtype.head_size[t]);
		}
		printf("this is num i: %d\n",*i);*/
		int64_t j = 0;
		while(j <= (*i) - 1){
			//printf("key size is:%d", headtype.head_size[j]);
			offset_in_head += headtype.head_size[j];   //find the position of the key
			j++;
		}
		//printf("\n");
		//j++;
		one_key_size = headtype.head_size[j];
		ReaderNAS::Seek(trace_num);
		//_gf_head->SeekToBegin();
		//printf("trace_num is:%d\n",trace_num);
		//printf("seek to begin position is:%d\n",_gf_head->SeekToBegin());
		//printf("one_key_size is:%d\n",one_key_size);
		//printf("position is:%d\n",_gf_head->GetPosition());
		//printf("offset in head is:%d\n",offset_in_head);
		_gf_head->Seek(offset_in_head, SEEK_CUR);  //seek to the key position
		//printf("position is:%d after seek\n",_gf_head->GetPosition());
		//_gf_head->SeekToEnd();
		//printf("position is after seek to end:%d\n",_gf_head->GetPosition());
		_gf_head->Read(p, one_key_size);
		p[one_key_size] = '\0';
		//printf("p is:%s\n",p);
		//char *tp = (char *)malloc(sizeof(one_key_size));
		//memcpy(tp, p, one_key_size);
		//printf("this key is:%s,head is:%s\n",tp,head);
		p += one_key_size;
		//printf("%d ",*i);
	}

	//read trace
	char *p1 = (char *)trace;
	//ReaderNAS::Seek(trace_num);
	_gf_trace->Read(p1, _meta->MetaGettracelength());
	//printf("tracelength is:%d\n",_meta->MetaGettracelength());
	p1[_meta->MetaGettracelength()]='\0';

	return true;

}

/**
 * Return true if there are more heads. The routine usually accompany with NextHead
 */
bool ReaderNAS::HasNext() {
	//printf("current trace num is:%d\n",ReaderNAS::Tell());
	if(ReaderNAS::Tell() < ReaderNAS::GetTraceNum()){ //modify equal
		return true;
	}
	return false;
}

bool ReaderNAS::Next(void* head, void* trace){ //Next(void* head) {
	if(ReaderNAS::HasNext()){
		return ReaderNAS::Get(ReaderNAS::Tell()/* + 1*/, head, trace);  //plus 1
	}
	printf("No next trace\n");
	return false;
}

bool ReaderNAS::Close() {
	_gf_head->Close();
	_gf_trace->Close();
	delete _gf_head;
	delete _gf_trace;
	delete _meta;
	return true;
}

}

}


