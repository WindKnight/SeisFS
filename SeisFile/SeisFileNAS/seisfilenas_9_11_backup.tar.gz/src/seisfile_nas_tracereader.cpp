/*
 * seisfile_nas_tracereader.cpp
 *
 *  Created on: Jun 26, 2018
 *      Author: wyd
 */

#include "seisfile_nas_tracereader.h"
#include <seisfile_nas_meta.h>

namespace seisfs {

namespace file {

TraceReaderNAS::~TraceReaderNAS(){

}

TraceReaderNAS::TraceReaderNAS(const std::string& filename){
	_trace_filename = SEISNAS_HOME_PATH + filename + "_trace";
	_meta_filename = SEISNAS_HOME_PATH + filename +"_meta";
	_filename = filename;
	TraceReaderNAS::Init();
}

bool TraceReaderNAS::Init(){
	_gf_trace = new GEFile(_trace_filename);
	_gf_trace->SetProjectName(_filename + "trace");
	_meta = new MetaNAS(_meta_filename);
	_meta->MetaRead();
	return _gf_trace->Open(IO_READONLY, true);
}

/*
 * caller should not delete the pointer of filter after calling this function
 */
bool TraceReaderNAS::SetRowFilter(const RowFilter& row_filter) {
	_row_filter = row_filter;
	return true;
}

/**
 * Get the total trace rows of seis.
 */
int64_t TraceReaderNAS::GetTraceNum() {
	int64_t tracenum = 0;
	int64_t temp = 0;
	for(int i = 0; i < _row_filter.GetAllScope().size(); i++){
		if(_row_filter.GetAllScope()[i].GetStopTrace() != -1){
			temp = _row_filter.GetAllScope()[i].GetStopTrace() - _row_filter.GetAllScope()[i].GetStartTrace() + 1;
		}
		else{
			temp = _meta->MetaGettracenum()- _row_filter.GetAllScope()[i].GetStartTrace();
		}
		tracenum += temp;
	}
	return tracenum;
}

/**
 * Get the trace length.
 */
int64_t TraceReaderNAS::GetTraceSize() {
	_trace_type = _meta->MetaGettracetype();
	return _trace_type.trace_size;
}//return length of one trace, in bytes

/**
 * Move the read offset to trace_idx(th) trace.
 */
bool TraceReaderNAS::Seek(int64_t trace_num) {
	if(trace_num > TraceReaderNAS::GetTraceNum() - 1){//_meta->MetaGettracenum() - 1){
		//index out of range
		printf("trace index out of range!\n");
		return false;
	}
	int64_t trace_pos = 0;
	int64_t count = 0;  //find actual tracenum by checking rowfilter
	int64_t cur_scope_num = 0;
	int64_t temp;  //record tracenum of one scope
	while((count <= trace_num) && (cur_scope_num < _row_filter.GetAllScope().size())){
		if(_row_filter.GetAllScope()[cur_scope_num].GetStopTrace() != -1){
			temp = _row_filter.GetAllScope()[cur_scope_num].GetStopTrace() - _row_filter.GetAllScope()[cur_scope_num].GetStartTrace() + 1;
		}
		else{
			temp = trace_num - _row_filter.GetAllScope()[cur_scope_num].GetStartTrace() + 1;
		}
		count += temp;
		cur_scope_num++;
	}
	cur_scope_num--;
	temp = (_row_filter.GetAllScope()[cur_scope_num].GetStopTrace() == -1) ? trace_num : _row_filter.GetAllScope()[cur_scope_num].GetStopTrace();
	_actual_trace_num = temp - (count - trace_num) + 1;
	trace_pos = _actual_trace_num * _meta->MetaGettracelength();
	_gf_trace->Seek(trace_pos, SEEK_SET);

	return true;
}

int64_t TraceReaderNAS::Tell() {
	int64_t pos = _gf_trace->GetPosition();
	int64_t physical_tracenum = pos / _meta->MetaGettracelength();
	int64_t trace_num = 0;
	int64_t temp = 0;
	int mark = 0;
	for(int i = 0; i < _row_filter.GetAllScope().size(); i++){
		if(mark == 1){
			break;
		}
		temp = (_row_filter.GetAllScope()[i].GetStopTrace() == -1)?_meta->MetaGettracenum():_row_filter.GetAllScope()[i].GetStopTrace();
		for(int64_t j = _row_filter.GetAllScope()[i].GetStartTrace(); j <= temp; j++){
			if(physical_tracenum != j){
				trace_num++;
			}
			else{
				mark = 1;
				break;
			}
		}
	}
	trace_num++;
	return trace_num;
}

/**
 * Get a trace by trace index.
 */
bool TraceReaderNAS::Get(int64_t trace_num, void* trace) {
	/*float *p_read = (float*)trace;
	for(int i = 0; i < 3000; ++i) {
		p_read[i] = -1.0 * trace_idx;
	}
	return true;*/
	TraceReaderNAS::Seek(trace_num);
	char *p = (char *)trace;
	_gf_trace->Read(p, _meta->MetaGettracelength());
	p[_meta->MetaGettracelength()]='\0';
	return true;
}

/**
 * Return true if there are more traces. The routine usually accompany with NextTrace.
 */
bool TraceReaderNAS::HasNext() {
	if(TraceReaderNAS::Tell() < TraceReaderNAS::GetTraceNum()){
		return true;
	}
	return false;
}

/**
 * Get a trace by filter.
 */
bool TraceReaderNAS::Next(void* trace) {
	if(TraceReaderNAS::HasNext()){
			return TraceReaderNAS::Get(TraceReaderNAS::Tell(), trace);  //plus 1
	}
	printf("No next trace\n");
	return false;
}

/**
 * Close file.
 */
bool TraceReaderNAS::Close() {
	_gf_trace->Close();
	delete _gf_trace;
	delete _meta;
	return true;
}


}
}


