/*
 * seisfile_nas_writer.cpp
 *
 *  Created on: July 16, 2018
 *      Author: cssl
 */
 
 #include "seisfile_nas_writer.h"
 #include <string>
 #include <GEFile.h>
 #include <seisfile_nas_meta.h>
 #include <iostream>
 #include <cstring>

 namespace seisfs {
	namespace file{

		WriterNAS::WriterNAS(const std::string& filename, const HeadType &head_type, const TraceType& trace_type, Lifetime lifetime_days){//, MetaNAS *meta){
			//_head_filename = filename + "/head";
			_head_filename = SEISNAS_HOME_PATH + filename + "_head";
			_trace_filename = SEISNAS_HOME_PATH + filename + "_trace";
			_meta_filename = SEISNAS_HOME_PATH + filename +"_meta";
			_filename = filename;
			_head_type = head_type;
			_trace_type = trace_type;
			_lifetime_days = lifetime_days;

			_head_length = 0;
			for(int i = 0; i < _head_type.head_size.size(); i++){
				_head_length +=_head_type.head_size[i];
			}

			WriterNAS::Init();
		}

		bool WriterNAS::Init() {
			_gf_head = new GEFile(_head_filename);
			_gf_trace = new GEFile(_trace_filename);
			//_gf_meta = new GEFile(_meta_filename);
            _gf_head->SetProjectName(_filename + "head");
            _gf_trace->SetProjectName(_filename + "trace");
            //_gf_meta->SetProjectName(_filename + "meta");
            //_gf_meta->Open(IO_WRITEONLY, true);
            meta = new MetaNAS(_meta_filename, _head_type, _trace_type, _lifetime_days);
            meta->MetaRead();
            //std::cout<<meta->MetaGettracenum();
            //std::cout<<"\n";
            return (_gf_head->Open(IO_WRITEONLY, true) && _gf_trace->Open(IO_WRITEONLY, true));
		}

		WriterNAS::~WriterNAS(){
			//meta->~MetaNAS();
//			Close();
		}
		
		bool WriterNAS::Write(const void* head, const void* trace){
			//std::cout<<"come in\nthis is head";
			if(!_gf_head->IsOpen() || !_gf_trace->IsOpen()) {
				//file is not open
				return false;
			}
			_gf_head->SeekToEnd();
			//_gf_head->Write(head, strlen((const char*)head));
			_gf_head->Write(head, _head_length);
			meta->MetaheadnumPlus();
			_gf_trace->SeekToEnd();
			//_gf_trace->Write(trace, strlen((const char*)trace));
			_gf_trace->Write(trace, _trace_type.trace_size);
			meta->MetatracenumPlus();

			//std::cout<<"\nthis is length\n";
			//std::cout<<_gf_head->GetLength();
			return true;
		}
		
		int64_t WriterNAS::Pos(){

			/*_gf_head->SeekToEnd();
			std::cout<<_gf_head->GetPosition();
			std::cout<<"\n";
			return _gf_head->GetPosition();*/

			//return 0;
			return meta->MetaGetheadnum()>meta->MetaGetheadnum()?meta->MetaGetheadnum():meta->MetaGetheadnum();
		}
		
		bool WriterNAS::Sync(){
			_gf_head->Flush();
			_gf_trace->Flush();
			return true;
		}
		
		bool WriterNAS::Close(){
			//std::cout<<"before update\n";
			//std::cout<<meta->MetaGetheadnum();
			//std::cout<<"\n";
			meta->MetaUpdate();
			//std::cout<<"after update\n";
			//std::cout<<meta->MetaGetheadnum();
			//std::cout<<"\n";
			_gf_head->Close();
			_gf_trace->Close();
			delete _gf_head;
			delete _gf_trace;
			delete meta;
			return true;
		}
		
		bool WriterNAS::Truncate(int64_t trace_num){
			meta->MetaSetheadnum(trace_num);
			meta->MetaSettracenum(trace_num);
			return true;
		}
	
	}
 }
