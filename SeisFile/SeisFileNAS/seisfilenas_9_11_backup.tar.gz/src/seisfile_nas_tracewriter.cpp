/*
 * seisfile_nas_writer.cpp
 *
 *  Created on: Aug 5, 2018
 *      Author: cssl
 */

#include "seisfile_nas_tracewriter.h"
#include <GEFile.h>
#include "seisfile_nas_meta.h"
#include <string>

namespace seisfs {

namespace file {

	TraceWriterNAS::~TraceWriterNAS(){
		meta->~MetaNAS();
	}

	TraceWriterNAS::TraceWriterNAS(const TraceType &trace_type,const std::string& filename, Lifetime lifetime_days) {
		_trace_filename = SEISNAS_HOME_PATH + filename + "_trace";
		_meta_filename = SEISNAS_HOME_PATH + filename +"_meta";
		_filename = filename;
		_trace_type = trace_type;
		_lifetime_days = lifetime_days;
		TraceWriterNAS::Init();
	}

	bool TraceWriterNAS::Write(const void* trace) {
		if(!_gf_trace->IsOpen()) {
			//file is not open
			return false;
		}
		meta->MetaheadnumPlus();
		_gf_trace->SeekToEnd();
		_gf_trace->Write(trace, _trace_type.trace_size);
		meta->MetatracenumPlus();
		return true;
	}

	int64_t TraceWriterNAS::Pos() {
		return meta->MetaGetheadnum();
	}

	bool TraceWriterNAS::Sync() {
		_gf_trace->Flush();
		return true;
	}

	bool TraceWriterNAS::Close() {
		meta->MetaUpdate();
		_gf_trace->Close();
		delete _gf_trace;
		delete meta;
		return true;
	}

	bool TraceWriterNAS::Truncate(int64_t trace_num) {
		meta->MetaSetheadnum(trace_num);
		return true;
	}

	bool TraceWriterNAS::Init(){
		_gf_trace = new GEFile(_trace_filename);
		_gf_trace->SetProjectName(_filename + "trace");
		meta = new MetaNAS(_meta_filename, _trace_type, _lifetime_days);
		meta->MetaRead();
		return _gf_trace->Open(IO_WRITEONLY, true);
	}

}

}
