/*
 * seisfile_nas_writer.cpp
 *
 *  Created on: July 22, 2018
 *      Author: cssl
 */

#include "seisfile_nas_headwriter.h"
#include <GEFile.h>
#include "seisfile_nas_meta.h"
#include <string>

namespace seisfs {

namespace file {

	HeadWriterNAS::~HeadWriterNAS(){
		meta->~MetaNAS();
	}

	HeadWriterNAS::HeadWriterNAS(const HeadType &head_type,const std::string& filename, Lifetime lifetime_days) {
		/*_headfilename = filename;
		//GEFile _gf(_gefilename);
		_gf = gf;
		_head_length = meta.head_length;
		_head = &head_type;*/
		_head_filename = SEISNAS_HOME_PATH + filename + "_head";
		_meta_filename = SEISNAS_HOME_PATH + filename +"_meta";
		_filename = filename;
		_head_type = head_type;
		_lifetime_days = lifetime_days;

		_head_length = 0;
		for(int i = 0; i < _head_type.head_size.size(); i++){
			_head_length +=_head_type.head_size[i];
		}

		HeadWriterNAS::Init();
	}

	bool HeadWriterNAS::Write(const void* head) {
		if(!_gf_head->IsOpen()){
			//file is not open
			return false;
		}
		_gf_head->SeekToEnd();
		_gf_head->Write(head, _head_length);
		meta->MetaheadnumPlus();
		return true;
	}

	int64_t HeadWriterNAS::Pos() {
		return meta->MetaGetheadnum();
	}

	bool HeadWriterNAS::Sync() {
		_gf_head->Flush();
		return true;
	}

	bool HeadWriterNAS::Close() {
		meta->MetaUpdate();
		_gf_head->Close();
		delete _gf_head;
		delete meta;
		return true;
	}

	bool HeadWriterNAS::Truncate(int64_t trace_num) {
		meta->MetaSetheadnum(trace_num);
		return true;
	}

	bool HeadWriterNAS::Init(){
		_gf_head = new GEFile(_head_filename);
		_gf_head->SetProjectName(_filename + "head");
		meta = new MetaNAS(_meta_filename, _head_type, _lifetime_days);
		meta->MetaRead();
		return _gf_head->Open(IO_WRITEONLY, true);
	}

}

}
