/*
 * seisfile_headreader.h
 *
 *  Created on: Mar 26, 2018
 *      Author: wyd
 */

#ifndef SEISFILE_NAS_HEADREADER_H_
#define SEISFILE_NAS_HEADREADER_H_

#include "seisfile_headreader.h"
#include <seisfs_head_filter.h>
#include <seisfs_row_filter.h>
#include <seisfile_headreader.h>
#include <GEFile.h>
#include <seisfile_nas_meta.h>

namespace seisfs {

class HeadFilter;
class RowFilter;

namespace file {

class MetaNAS;
class Headtype;

class HeadReaderNAS : public HeadReader {
public:

    virtual ~HeadReaderNAS();

    HeadReaderNAS(const std::string& filename);

    /*
     * caller should not delete the pointer of filter after calling this function
     */
    bool SetHeadFilter(const HeadFilter& head_filter);

    /*
     * caller should not delete the pointer of filter after calling this function
     */
    bool SetRowFilter(const RowFilter& row_filter);

    int GetHeadSize(); //return length of one head, in bytes

    int64_t GetTraceNum();

    /**
     * Move the read offset to head_idx(th) head.
     */
    bool Seek(int64_t head_nun);

    int64_t Tell();

    bool Get(int64_t head_num, void* head);

    /**
     * Return true if there are more heads. The routine usually accompany with NextHead
     */
    bool HasNext();

    bool Next(void* head);

    bool Close();

    bool Init();

private:

    HeadFilter _head_filter;
    RowFilter _row_filter;

    int64_t _actual_trace_num;

    std::string _head_filename;
    std::string _meta_filename;
    std::string _filename;
    const std::string SEISNAS_HOME_PATH = "/d0/data/seisfiletest/seisfiledisk/";
    GEFile *_gf_head;
    HeadType _head_type;
    Lifetime _lifetime_days;
    MetaNAS *_meta;

};

}

}

#endif /* SEISFILE_NAS_HEADREADER_H_ */
