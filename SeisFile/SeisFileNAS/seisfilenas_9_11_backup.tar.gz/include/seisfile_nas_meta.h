/*
 * seisfile_meta.h
 *
 *  Created on: Mar 26, 2018
 *      Author: wyd
 */

#ifndef SEISFILE_NAS_META_H_
#define SEISFILE_NAS_META_H_


#include "seisfs_meta.h"
#include <vector>
#include <string>
#include <stddef.h>
#include <time.h>
#include "seisfile_meta.h"
#include "GEFile.h"

namespace seisfs {

	namespace file {

		#define LIFETIME_NULL 		-1
		#define LIFETIME_DEFAULT 	30

		class MetaNAS {
		public :

			MetaNAS(const std::string &data_name, const HeadType &head_type, const TraceType& trace_type, Lifetime lifetime_days);

			MetaNAS(const std::string &data_name, const HeadType &head_type, Lifetime lifetime_days);

			MetaNAS(const std::string &data_name, const TraceType& trace_type, Lifetime lifetime_days);

			MetaNAS(const std::string &data_name);

			~MetaNAS();

			//void Init();

			bool MetaRead();

			bool MetaUpdate();

			void MetaheadnumPlus();

			void MetatracenumPlus();

			HeadType MetaGetheadtype();

			TraceType MetaGettracetype();

			void MetaSetheadnum(const uint32_t& headnum);

			void MetaSettracenum(const uint32_t& tracenum);

			uint32_t MetaGetheadnum();

			uint32_t MetaGettracenum();

			uint32_t MetaGetheadlength();

			uint32_t MetaGettracelength();

			uint32_t MetaGetkeynum();

			time_t MetaGetLastModify();

			bool MetaSetLifetime(Lifetime lifetime_days);

			Lifetime MetaGetLifetime();

			LifetimeStat MetaGetLifetimestat();

			LifetimeStat MetaSetLifetimestat(LifetimeStat lt_stat);


		private:
			int _metauser; // 0 means Reader uses meta,1 means Writer uses meta
			std::string _filename;
			time_t _creat_time=0;
			time_t _lastmodify_time=0;
			uint32_t _head_num;  //record traces of data
			uint32_t _trace_num;

			uint32_t _head_length;
			int _keynum;
			HeadType _head_type;
			TraceType _trace_type;
			Lifetime _life_time;
			GEFile *_gf_meta;
			Lifetime _lifetime_days;
			LifetimeStat _lifetimestat;

		};


	}

}

#endif /* SEISFILE_NAS_META_H_ */
