/*
 * seisfile_writer.h
 *
 *  Created on: Mar 26, 2018
 *      Author: wyd
 */

#ifndef SEISFILE_NAS_WRITER_H_
#define SEISFILE_NAS_WRITER_H_

#include <stdint.h>
#include <seisfile_nas_meta.h>
#include "seisfile_writer.h"
#include "GEFile.h"



namespace seisfs {

namespace file {

class HeadWriterNAS;
class TraceWriterNAS;
class MetaNAS;
//class GEFile;

class WriterNAS : public Writer{
public:

	//WriterNAS(const std::string& filename, MetaNAS *meta);
	//WriterNAS(const std::string& filename);
	 WriterNAS(const std::string& filename, const HeadType &head_type, const TraceType& trace_type, Lifetime lifetime_days);

     virtual ~WriterNAS();

    /**
     * Append a trace head
     */
     bool Write(const void* head, const void* trace);

     bool Init();

    /**
     * Returns the position that data is written to.
     */
     int64_t Pos();

    /**
     * Transfers all modified in-core data of the file to the disk device where that file resides.
     */
     bool Sync();

    /**
     * Close file.
     */
     bool Close();

     bool Truncate(int64_t trace_num);

private:

     std::string _head_filename;
     std::string _trace_filename;
     std::string _meta_filename;
     std::string _filename;
     const std::string SEISNAS_HOME_PATH = "/d0/data/seisfiletest/seisfiledisk/";
     GEFile *_gf_head, *_gf_trace;//, *_gf_meta;
     int64_t _head_length;
     HeadType _head_type;
     TraceType _trace_type;
     Lifetime _lifetime_days;
     MetaNAS *meta;
};

}

}

#endif /* SEISFILE_NAS_WRITER_H_ */
